<img src="<?php echo e(asset('images/logo.png')); ?>" width="100" height="150"/>
<?php /**PATH C:\xampp\htdocs\mtg\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>