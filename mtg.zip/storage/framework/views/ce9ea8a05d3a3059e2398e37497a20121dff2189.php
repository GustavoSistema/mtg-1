<a href="/">
    <img src="<?php echo e(asset('images/logo.png')); ?>" width="250" height="150"/>
</a>
<?php /**PATH C:\xampp\htdocs\mtg\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>