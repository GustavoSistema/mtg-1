<?php return array (
  'create-expediente' => 'App\\Http\\Livewire\\CreateExpediente',
  'edit-file' => 'App\\Http\\Livewire\\EditFile',
  'expedientes' => 'App\\Http\\Livewire\\Expedientes',
);